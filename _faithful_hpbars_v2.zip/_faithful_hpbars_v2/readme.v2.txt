Faithful Health Bars v2
by Keanine

This pack updates the textures of the health bars above enemies and vehicles heads to provide a cleaner look. This isn't based on reference material, however it is a modification of the existing textures so it should remain faithful to the style they were going for. This also includes a minor change to the score bars, if you don't like it then remove the score folder.

This pack will take priority over most packs, so if you download a new pack that modifies health bars or score bars then make sure to uninstall this one.

INSTRUCTIONS:

Open Dolphin, go to Graphics, Advanced, Utility and enable Load Custom Textures. Close the graphics window.

Extract the _faithful_hpbars folder into your RABAZZ folder located in: %Appdata%/Dolphin Emulator/Load/Textures/

Do not take the folders out of the _faithful_hpbars folder unless you know what you're doing.

For example, it should look like this:
C:/Users/USERNAME/AppData/Roaming/Dolphin Emulator/Load/Textures/RABAZZ/_faithful_hpbars/
